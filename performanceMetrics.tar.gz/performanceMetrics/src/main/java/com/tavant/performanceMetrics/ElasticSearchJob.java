package com.tavant.performanceMetrics;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.tavant.performanceMetrics.data.MetricsData;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsOrgLevelFlatRepo;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsProjectLevelFlatRepo;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsRepo;
import com.tavant.performanceMetrics.service.PerformanceMetricsService;

public class ElasticSearchJob implements Job {

	private static final Logger LOGGER = LoggerFactory.getLogger(ElasticSearchJob.class);

	@Autowired
	PerformanceMetricsRepo performanceMetricsRepo;
	
	@Autowired
	PerformanceMetricsService performanceMetricsService;
	

	@Autowired
	PerformanceMetricsOrgLevelFlatRepo performanceMetricsOrgLevelRepoFlat;

	@Autowired
	PerformanceMetricsProjectLevelFlatRepo performanceMetricsProjRepoFlat;

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	public String getYesterdaysDate() {

		LocalDate yesterday = LocalDate.now().minusDays(1);
		String formattedDate = yesterday.format(formatter);
		return formattedDate;

	}

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		LOGGER.debug("SimpleJob is executing...");


		Iterable<MetricsData> perfMetrics = performanceMetricsService.getAllMetricsRawData();

		performanceMetricsService.extractProjectLevelAndUserLevelMetrics(perfMetrics);

	}

		


}
