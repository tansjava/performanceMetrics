package com.tavant.performanceMetrics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.performanceMetrics.data.ProjectMetricsDataFlat;
import com.tavant.performanceMetrics.service.PerformanceMetricsService;

@RestController
public class PerformanceMetricsController {

	@Autowired
	PerformanceMetricsService performanceMetricsService;
	
	
	@GetMapping("/getPerfMetricsByOrg")
	public List<ProjectMetricsDataFlat> getProjectMetricsDataFlat(){
		
		return performanceMetricsService.getProjectLevelAndUserLevelMetrics();
		
	}
	
	
	@GetMapping("/getPerfMetricsByOrgBetweenDates")
	public List<ProjectMetricsDataFlat> getProjectMetricsDataFlatBetweenDates(@RequestParam String startDate, @RequestParam String endDate){
		
		return performanceMetricsService.getProjectMetricsDataFlatBetweenDates(startDate, endDate);
		
	}
	
	
}
