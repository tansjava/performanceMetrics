package com.tavant.performanceMetrics.data;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document(indexName = "github")
public class MetricsData {
	
	@Id
    private String _id;
	
    private String organization;
    private int repoCount;
    private String date;
    private String to;
    private String from;
    private int noOfCommits;
    private int pulls;
    @JsonProperty("projectMetrics")
    private List<ProjectMetric> projectMetrics;
    private List<UserMetric> users;
	public String get_id() {
		return _id;
	}
	public String getOrganization() {
		return organization;
	}
	public int getRepoCount() {
		return repoCount;
	}
	public String getDate() {
		return date;
	}
	public String getTo() {
		return to;
	}
	public String getFrom() {
		return from;
	}
	public int getNoOfCommits() {
		return noOfCommits;
	}
	public int getPulls() {
		return pulls;
	}
	public List<ProjectMetric> getProjectMetrics() {
		return projectMetrics;
	}
	public List<UserMetric> getUsers() {
		return users;
	}
    
    

    // Getters and setters
}

 