package com.tavant.performanceMetrics.data;

import java.util.List;

public class ProjectMetric {
	 private String repoName;
	    private int commits;
	    private int pulls;
	    public String getRepoName() {
			return repoName;
		}
		public void setRepoName(String repoName) {
			this.repoName = repoName;
		}
		public int getCommits() {
			return commits;
		}
		public void setCommits(int commits) {
			this.commits = commits;
		}
		public int getPulls() {
			return pulls;
		}
		public void setPulls(int pulls) {
			this.pulls = pulls;
		}
		public List<User> getUsers() {
			return users;
		}
		public void setUsers(List<User> users) {
			this.users = users;
		}
		private List<User> users;

}
