package com.tavant.performanceMetrics.data;

import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "github_data_denorm_project")
public class ProjectMetricsDataFlat extends UserMetricsDataFlat{

	String repoName;

	public String getRepoName() {
		return repoName;
	}

	public void setRepoName(String repoName) {
		this.repoName = repoName;
	}

	
	
	
	
}
