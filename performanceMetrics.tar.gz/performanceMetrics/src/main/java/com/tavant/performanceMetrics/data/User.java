package com.tavant.performanceMetrics.data;

import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
	  private String user;
	    private int additions;
	    private int deletions;
	    @JsonProperty("total_lines_change")
	    private int totalLinesChange;
	    private int commits;
	    private int pulls;
		public String getUser() {
			return user;
		}
		public int getAdditions() {
			return additions;
		}
		public int getDeletions() {
			return deletions;
		}
		public int getTotalLinesChange() {
			return totalLinesChange;
		}
		public int getCommits() {
			return commits;
		}
		public int getPulls() {
			return pulls;
		}
	    
	    
}
