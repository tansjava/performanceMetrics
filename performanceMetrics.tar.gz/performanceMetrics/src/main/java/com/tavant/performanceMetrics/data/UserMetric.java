package com.tavant.performanceMetrics.data;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserMetric {
	
    @Field(name = "user_name")
    private String userName;
    private int commits;
    private int additions;
    private int deletions;
    @JsonProperty("total_lines_change")
    private int totalLinesChange;
	public String getUserName() {
		return userName;
	}
	public int getCommits() {
		return commits;
	}
	public int getAdditions() {
		return additions;
	}
	public int getDeletions() {
		return deletions;
	}
	public int getTotalLinesChange() {
		return totalLinesChange;
	}

}
