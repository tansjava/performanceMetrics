package com.tavant.performanceMetrics.data;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document(indexName = "github_data_denorm")
public class UserMetricsDataFlat {



	@Id
	private String _id;

    //@Convert(converter = StringToLocalDateConverter.class)
    //private LocalDate date;
    
    @Field(type = FieldType.Date, format = DateFormat.date_optional_time)
    private String date; // Date field in string format

    
	@Field(name = "user_name")
	private String userName;
	private int commits;
	private int additions;
	private int deletions;
	@JsonProperty("total_lines_change")
	private int totalLinesChange;

	private String organization;
	
	private String category;


	

    
    
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	private String metricType;

	public String getMetricType() {
		return metricType;
	}

	public void setMetricType(String metricType) {
		this.metricType = metricType;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setCommits(int commits) {
		this.commits = commits;
	}

	public void setAdditions(int additions) {
		this.additions = additions;
	}

	public void setDeletions(int deletions) {
		this.deletions = deletions;
	}

	public void setTotalLinesChange(int totalLinesChange) {
		this.totalLinesChange = totalLinesChange;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}



	public String getUserName() {
		return userName;
	}

	public int getCommits() {
		return commits;
	}

	public int getAdditions() {
		return additions;
	}

	public int getDeletions() {
		return deletions;
	}

	public int getTotalLinesChange() {
		return totalLinesChange;
	}

	public String getOrganization() {
		return organization;
	}

	
	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	

}
