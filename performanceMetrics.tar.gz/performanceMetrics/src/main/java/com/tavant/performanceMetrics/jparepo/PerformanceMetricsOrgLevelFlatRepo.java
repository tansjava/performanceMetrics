package com.tavant.performanceMetrics.jparepo;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

import com.tavant.performanceMetrics.data.UserMetricsDataFlat;


@Component
public interface PerformanceMetricsOrgLevelFlatRepo extends ElasticsearchRepository<UserMetricsDataFlat, String> {

	

}


