package com.tavant.performanceMetrics.jparepo;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

import com.tavant.performanceMetrics.data.ProjectMetricsDataFlat;


@Component
public interface PerformanceMetricsProjectLevelFlatRepo extends ElasticsearchRepository<ProjectMetricsDataFlat, String> {

    List<ProjectMetricsDataFlat> findByDateBetweenOrderByAdditionsDesc(String startDate, String endDate);
	

}


