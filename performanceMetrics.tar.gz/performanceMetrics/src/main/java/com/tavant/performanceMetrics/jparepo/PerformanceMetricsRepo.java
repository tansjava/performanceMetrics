package com.tavant.performanceMetrics.jparepo;

import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

import com.tavant.performanceMetrics.data.MetricsData;

@Component
public interface PerformanceMetricsRepo  extends ElasticsearchRepository<MetricsData, String> {

	List<MetricsData> findByDate(String formattedDateYesterday);

	

}
