package com.tavant.performanceMetrics.service;

import java.util.List;

import com.tavant.performanceMetrics.data.MetricsData;
import com.tavant.performanceMetrics.data.ProjectMetricsDataFlat;

public interface PerformanceMetricsService {
	public Iterable<MetricsData> getAllMetricsRawData();

	void extractProjectLevelAndUserLevelMetrics(Iterable<MetricsData> perfMetrics);
	
	List<ProjectMetricsDataFlat> getProjectLevelAndUserLevelMetrics();


	public List<ProjectMetricsDataFlat> getProjectMetricsDataFlatBetweenDates(String startDate, String endDate);

}
