package com.tavant.performanceMetrics.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tavant.performanceMetrics.data.MetricsData;
import com.tavant.performanceMetrics.data.ProjectMetric;
import com.tavant.performanceMetrics.data.ProjectMetricsDataFlat;
import com.tavant.performanceMetrics.data.User;
import com.tavant.performanceMetrics.data.UserMetric;
import com.tavant.performanceMetrics.data.UserMetricsDataFlat;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsOrgLevelFlatRepo;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsProjectLevelFlatRepo;
import com.tavant.performanceMetrics.jparepo.PerformanceMetricsRepo;
import com.tavant.performanceMetrics.utils.DateUtils;

@Component
public class PerformanceMetricsServiceImpl implements PerformanceMetricsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PerformanceMetricsServiceImpl.class);

	String[] categoryArray = new String[] {
	"ABCDE", "FGHIJ", "KLMNO", "PQRST", "UVWXYZ" 

			
	};
	
	@Autowired
	PerformanceMetricsRepo performanceMetricsRepo;

	@Autowired
	PerformanceMetricsOrgLevelFlatRepo performanceMetricsOrgLevelRepoFlat;

	@Autowired
	PerformanceMetricsProjectLevelFlatRepo performanceMetricsProjRepoFlat;

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Autowired
    DateUtils dateUtils;
    
	@Override
	public Iterable<MetricsData> getAllMetricsRawData() {
		{
			Iterable<MetricsData> perfMetrics = performanceMetricsRepo.findAll();
			return perfMetrics;
		}
	}

	@Override
	public void extractProjectLevelAndUserLevelMetrics(Iterable<MetricsData> perfMetrics) {
		List<UserMetricsDataFlat> userMetricsDataFlatList = new ArrayList<>();

		List<ProjectMetricsDataFlat> projectMetricsDataFlatList = new ArrayList<>();

		for (MetricsData perfMetric : perfMetrics) {

			Integer commitsOrganizationLevel = perfMetric.getNoOfCommits();
			String date = perfMetric.getDate();
			String organization = perfMetric.getOrganization();
			Integer pulls = perfMetric.getPulls();
			List<UserMetric> userMetrics = perfMetric.getUsers();
			List<ProjectMetric> projMetrics = perfMetric.getProjectMetrics();

			LOGGER.info(" commitsOrganizationLevel {}", commitsOrganizationLevel);
			LOGGER.info(" date {}", date);
			LOGGER.info(" organization {}", organization);
			LOGGER.info(" pulls {}", pulls);

			extractAndSaveUserLevelDataAtOrganizationLevel(userMetricsDataFlatList, date, organization, userMetrics);

			extractUserLevelDataAtProjectLevel(projectMetricsDataFlatList, date, organization, projMetrics);

		}

	}

	private void extractUserLevelDataAtProjectLevel(List<ProjectMetricsDataFlat> projectMetricsDataFlatList,
			String date, String organization, List<ProjectMetric> projMetrics) {
		projMetrics.forEach(projMetric -> {

			List<User> users = projMetric.getUsers();

			String repoName = projMetric.getRepoName();

			users.forEach(user -> {

				Integer additions = user.getAdditions();
				Integer commits = user.getCommits();
				Integer deletions = user.getDeletions();
				Integer pullsUser = user.getPulls();
				Integer totalLinesChange = user.getTotalLinesChange();
				String userName = user.getUser();

				String category = getCategoryFromUserName(userName);
				
				LOGGER.info(" additions {}", additions);
				LOGGER.info(" commits {}", commits);
				LOGGER.info(" deletions {}", deletions);
				LOGGER.info(" pullsUser {}", pullsUser);
				LOGGER.info(" totalLinesChange {}", totalLinesChange);
				LOGGER.info(" userName {}", userName);
				LOGGER.info(" Category {}", category);

				ProjectMetricsDataFlat projectuserMetricsDataFlat = new ProjectMetricsDataFlat();
				projectuserMetricsDataFlat.setAdditions(additions);
				projectuserMetricsDataFlat.setCommits(commits);
				projectuserMetricsDataFlat.setDeletions(deletions);
				projectuserMetricsDataFlat.setTotalLinesChange(totalLinesChange);
				projectuserMetricsDataFlat.setUserName(userName);
				LocalDate dateObj = dateUtils.getDateFromString(date);
				projectuserMetricsDataFlat.setDate(date);
				projectuserMetricsDataFlat.setOrganization(organization);
				projectuserMetricsDataFlat.setMetricType("projectLevelUserMetric");
				projectuserMetricsDataFlat.setRepoName(repoName);
				projectuserMetricsDataFlat.setCategory(category);
				projectMetricsDataFlatList.add(projectuserMetricsDataFlat);
				// userMetricsDataFlat.set_id(organization);

				performanceMetricsProjRepoFlat.save(projectuserMetricsDataFlat);

			});

		});
	}

	private void extractAndSaveUserLevelDataAtOrganizationLevel(List<UserMetricsDataFlat> userMetricsDataFlatList, String date,
			String organization, List<UserMetric> userMetrics) {
		userMetrics.forEach(userMetric -> {

			Integer additions = userMetric.getAdditions();
			Integer commits = userMetric.getCommits();
			Integer deletions = userMetric.getDeletions();
			Integer totalLinesChange = userMetric.getTotalLinesChange();
			String userName = userMetric.getUserName();
			String category = getCategoryFromUserName(userName);
			LOGGER.info(" additions {}", additions);
			LOGGER.info(" commits {}", commits);
			LOGGER.info(" deletions {}", deletions);
			LOGGER.info(" totalLinesChange {}", totalLinesChange);
			LOGGER.info(" userName {}", userName);

			UserMetricsDataFlat userMetricsDataFlat = new UserMetricsDataFlat();
			userMetricsDataFlat.setAdditions(additions);
			userMetricsDataFlat.setCommits(commits);
			userMetricsDataFlat.setDeletions(deletions);
			userMetricsDataFlat.setTotalLinesChange(totalLinesChange);
			userMetricsDataFlat.setUserName(userName);			
			userMetricsDataFlat.setDate(date);
			userMetricsDataFlat.setOrganization(organization);
			userMetricsDataFlat.setMetricType("organizationLevelUserMetric");
			userMetricsDataFlat.setCategory(category);

			userMetricsDataFlatList.add(userMetricsDataFlat);
			// userMetricsDataFlat.set_id(organization);

			performanceMetricsOrgLevelRepoFlat.save(userMetricsDataFlat);

		});
	}

	private String getCategoryFromUserName(String userName) {
		
		String startChar = userName.substring(0,1);
		startChar =startChar.toUpperCase();
		String category = "";
		for(String cat : categoryArray) {
			if(cat.contains(startChar)) {
				category = "Cat-"+cat;
			}
		}
		return category;
	}

	@Override
	public List<ProjectMetricsDataFlat> getProjectLevelAndUserLevelMetrics() {		
		Iterable<ProjectMetricsDataFlat> metrics = performanceMetricsProjRepoFlat.findAll();
		 List<ProjectMetricsDataFlat> list = StreamSupport.stream(metrics.spliterator(), false)
                 .collect(Collectors.toList());
		 
		return list;
	}

	@Override
	public List<ProjectMetricsDataFlat> getProjectMetricsDataFlatBetweenDates(String startDate, String endDate){
		
        LocalDate startDt = LocalDate.parse(startDate, formatter);
        LocalDate endDt = LocalDate.parse(startDate, formatter);
       
		List<ProjectMetricsDataFlat>  projectMetricsDataFlat = performanceMetricsProjRepoFlat.findByDateBetweenOrderByAdditionsDesc(startDate, endDate);
		return projectMetricsDataFlat;
	}

	
	
	
}