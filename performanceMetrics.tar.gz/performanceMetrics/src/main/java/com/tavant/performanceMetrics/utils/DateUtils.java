package com.tavant.performanceMetrics.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

@Component
public class DateUtils {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    
	public  LocalDate getDateFromString(String date) {
		  LocalDate startDtLc = LocalDate.parse(date, formatter);
		  return startDtLc;
	}

}
