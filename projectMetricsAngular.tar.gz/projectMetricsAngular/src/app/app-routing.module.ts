import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectMetricsBarChartComponent } from './project-metrics-bar-chart/project-metrics-bar-chart.component';
import { ProjectMetricsLineChartComponent } from './project-metrics-line-chart/project-metrics-line-chart.component';
import { ProjectMetricsPieChartComponent } from './project-metrics-pie-chart/project-metrics-pie-chart.component';

const routes: Routes = [
  { path: '',  component: ProjectMetricsBarChartComponent },
  { path: 'bar-chart', component: ProjectMetricsBarChartComponent },
  { path: 'line-chart', component: ProjectMetricsLineChartComponent },
  { path: 'pie-chart', component: ProjectMetricsPieChartComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
