import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProjectMetricsBarChartComponent } from './project-metrics-bar-chart/project-metrics-bar-chart.component';
import { ProjectMetricsLineChartComponent } from './project-metrics-line-chart/project-metrics-line-chart.component';
import { ProjectMetricsPieChartComponent } from './project-metrics-pie-chart/project-metrics-pie-chart.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { FormsModule } from '@angular/forms'; // Import FormsModule

@NgModule({
  declarations: [
    AppComponent,
    ProjectMetricsBarChartComponent,
    ProjectMetricsLineChartComponent,
    ProjectMetricsPieChartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GoogleChartsModule,
    HttpClientModule,
    FormsModule,
    NgxDaterangepickerMd.forRoot()

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
