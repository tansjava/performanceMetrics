import { TestBed } from '@angular/core/testing';

import { ElasticSearchApiService } from './elastic-search-api.service';

describe('ElasticSearchApiService', () => {
  let service: ElasticSearchApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ElasticSearchApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
