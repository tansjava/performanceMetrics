import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {Dayjs} from 'dayjs';
@Injectable({
  providedIn: 'root'
})
export class ElasticSearchApiService {
  constructor(private http: HttpClient, private route: ActivatedRoute) { }

  getDataWithDateRange(start_date: Dayjs, end_date: Dayjs): Observable<any[]> {

    const formattedStartDate = this.formatDate(start_date);
    const formattedEndDate = this.formatDate(end_date);

    const url = 'https://localhost:9200/github_data_denorm/_search';

    const requestBody = {
      query: {
        range: {
          date: {
            gte: formattedStartDate,
            lte: formattedEndDate,
            format: 'yyyy-MM-dd'
          }
        }
      }
    };

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + btoa('elastic:15VyDQRod6mBPui37y7J') // Replace with actual username and password

      })
    };

    return this.http.post<any[]>(url, JSON.stringify(requestBody), httpOptions).pipe(
      map(responseData => this.extractUserMetrics(responseData))
    );
   
    
  }

  private formatDate(date: Dayjs): string {
    const year = date.year();
    const month = (date.month() + 1).toString().padStart(2, '0');
    const day = date.date().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private extractUserMetrics(responseData: any): any[] {
    const hits: any[] = responseData.hits?.hits || [];
    const extractedData = hits.map(hit => hit._source);

    return extractedData.map(data => ([
       data.user_name,
       data.commits,
       data.additions,
       data.deletions,
       data.totalLinesChange
      
    ]));
  }  

}
