import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {Dayjs} from 'dayjs';

@Injectable({
  providedIn: 'root'
})
export class MetricsService {

 
  constructor(private http: HttpClient) { }

  getUserMetrics(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:8080/getPerfMetricsByOrg').pipe(
      map(data => this.processMetrics(data))
    );
  }

  getUserMetricsBetweenDates(startDate:Dayjs, endDate: Dayjs): Observable<any[]> {

    const formattedStartDate = this.formatDate(startDate);
    const formattedEndDate = this.formatDate(endDate);
    const url = `http://localhost:8080/getPerfMetricsByOrgBetweenDates?startDate=${formattedStartDate}&endDate=${formattedEndDate}`;

   // const url = "http://localhost:8080/getPerfMetricsByOrgBetweenDates?startDate=${formattedStartDate}&endDate=${formattedEndDate}";
    return this.http.get<any[]>(url).pipe(
      map(data => this.processMetrics(data))
    );
  }


  private formatDate(date: Dayjs): string {
    const year = date.year();
    const month = (date.month() + 1).toString().padStart(2, '0');
    const day = date.date().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }


  private processMetrics(data: any[]): any[] {
    return data.map(userMetrics => [
      userMetrics.userName,
      userMetrics.commits,
      userMetrics.additions,
      userMetrics.deletions,
      userMetrics.total_lines_change
    ]);
  }


}
