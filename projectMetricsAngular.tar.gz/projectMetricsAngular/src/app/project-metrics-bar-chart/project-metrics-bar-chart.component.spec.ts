import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectMetricsBarChartComponent } from './project-metrics-bar-chart.component';

describe('ProjectMetricsBarChartComponent', () => {
  let component: ProjectMetricsBarChartComponent;
  let fixture: ComponentFixture<ProjectMetricsBarChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectMetricsBarChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectMetricsBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
