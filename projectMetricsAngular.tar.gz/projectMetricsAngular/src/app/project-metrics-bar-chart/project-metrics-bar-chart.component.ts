import { Component, OnInit } from '@angular/core';
import { ChartType } from 'angular-google-charts';
import { MetricsService } from '../metrics.service';
import { ElasticSearchApiService } from '../elastic-search-api.service';

import {Dayjs} from 'dayjs';
import * as dayjs from 'dayjs';

@Component({
  selector: 'app-project-metrics-bar-chart',
  templateUrl: './project-metrics-bar-chart.component.html',
  styleUrls: ['./project-metrics-bar-chart.component.css']
})
export class ProjectMetricsBarChartComponent implements OnInit {

  shouldHideDiv: boolean = false; // Set to true to hide the div

  selectedDateRange: { start: Dayjs, end: Dayjs };
  // column chart

  title = "User Commits";

  typeChart = ChartType.BarChart;



  columnsChartdatacolumn = [
    'UserName',
    'Commits',
    'Additions',
    'Deletions',
    'Total Lines Changed'
   

    ];

  columnsChartdata: any[][] = [];
  //columnsChartdatacolumn :any[]= [];
  columnsChartoptions = {

    //isStacked: true, // Set to true for grouped columns
    height: 1000,
    colors: ['blue', 'green', 'orange', 'yellow'],
    width: 1000,
    hAxis: {
      logScale: 'symlog',
      minValue: 1,
    }

  };

  ranges: any = {
    'Today': [dayjs(), dayjs()],
    'Yesterday': [dayjs().subtract(1, 'days'), dayjs().subtract(1, 'days')],
    'Last 7 Days': [dayjs().subtract(6, 'days'), dayjs()],
    'Last 30 Days': [dayjs().subtract(29, 'days'), dayjs()],
    'This Month': [dayjs().startOf('month'), dayjs().endOf('month')],
    'Last Month': [dayjs().subtract(1, 'month').startOf('month'), dayjs().subtract(1, 'month').endOf('month')]
  }


  optionsForDatePicker: any = {
   
    alwaysShowCalendars: true,
    keepCalendarOpeningWithRange: true,
    autoApply: false,
    showRangeLabelOnInput: false

    
};

  

  dateRangeChanged(event: any) {

     this.getMetricsForDateRangeFromElastic();

  }


  constructor(private userMetricsService: MetricsService,
    private elasticSearchApiService: ElasticSearchApiService ) {
    // Initialize selectedDateRange with a default range (e.g., last 7 days)
    const defaultEndDate = dayjs().startOf('day');
    //const defaultStartDate = new Dayjs(defaultEndDate);
    const defaultStartDate = dayjs().subtract(7, 'days');

    let defaultEndDateString = defaultEndDate.format('YYYY-MM-DD');

    let defaultStartDateString = defaultStartDate.format('YYYY-MM-DD');


    console.log('defaultEndDateString  '+defaultEndDateString);
    console.log('defaultStartDateString  '+defaultStartDateString);

   // defaultStartDate.date(defaultEndDate.date() - 6);
   
    this.selectedDateRange = {
      start: defaultStartDate,
      end: defaultEndDate
    };

    

    // this.selectedDateRange.startDate = defaultEndDate;

    // this.selectedDateRange.endDate = defaultEndDate;


    this.getMetricsForDateRangeFromElastic();

// Perform any actions based on the default selected date range
// For example, load chart data for the default range

   }




  private getMetricsForDateRange() {
    this.userMetricsService.getUserMetricsBetweenDates(this.selectedDateRange.start,
      this.selectedDateRange.end).subscribe(
        data => {
          console.log('data ' + data);
          this.extractedMetricsArray = data;
          this.updatePagedData();


        },
        error => {
          console.error('Error fetching user metrics:', error);

        }
      );
  }

  private getMetricsForDateRangeFromElastic() {
    this.elasticSearchApiService.getDataWithDateRange(this.selectedDateRange.start,
      this.selectedDateRange.end).subscribe(
        data => {
          console.log('data ' + data);
          this.extractedMetricsArray = data;
          this.updatePagedData();


        },
        error => {
          console.error('Error fetching user metrics:', error);

        }
      );
  }


  ngOnInit(): void {

   // this.fetchUserMetrics();

  
   
  }

  extractedMetricsArray: any[] = [];
  pageSize = 3; // Number of data points per page
  currentPage = 0; // Current page index
  pagedData: any[] = [];


  fetchUserMetrics() {
    this.userMetricsService.getUserMetrics().subscribe(
      data => {
        console.log('data ' + data);
        this.extractedMetricsArray = data;
        this.updatePagedData();


      },
      error => {
        console.error('Error fetching user metrics:', error);

      }
    );


  }


  updatePagedData() {
    const startIndex = this.currentPage * this.pageSize;
    const endIndex = startIndex + this.pageSize;

    if(this.extractedMetricsArray.slice(startIndex, endIndex).length > 0) {
      this.columnsChartdata = this.extractedMetricsArray.slice(startIndex, endIndex);
      this.shouldHideDiv = false;
    }else{
      this.shouldHideDiv = true; 
    }

  }

  previousPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.updatePagedData();
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.extractedMetricsArray.length / this.pageSize) - 1;
    if (this.currentPage < maxPage) {
      this.currentPage++;
      this.updatePagedData();
    }
  }



}
