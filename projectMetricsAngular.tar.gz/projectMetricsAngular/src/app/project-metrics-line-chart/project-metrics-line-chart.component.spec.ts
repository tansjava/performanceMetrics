import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectMetricsLineChartComponent } from './project-metrics-line-chart.component';

describe('ProjectMetricsLineChartComponent', () => {
  let component: ProjectMetricsLineChartComponent;
  let fixture: ComponentFixture<ProjectMetricsLineChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectMetricsLineChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectMetricsLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
