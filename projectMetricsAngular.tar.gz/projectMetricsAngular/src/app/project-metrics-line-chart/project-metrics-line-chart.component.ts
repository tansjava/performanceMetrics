import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-metrics-line-chart',
  templateUrl: './project-metrics-line-chart.component.html',
  styleUrls: ['./project-metrics-line-chart.component.css']
})
export class ProjectMetricsLineChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
