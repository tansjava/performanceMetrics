import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-metrics-pie-chart',
  templateUrl: './project-metrics-pie-chart.component.html',
  styleUrls: ['./project-metrics-pie-chart.component.css']
})
export class ProjectMetricsPieChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
